import React, { useState } from 'react';
import {
  UploadCloud,
  CheckCircle2,
  AlertCircle,
  X,
  Minimize2,
  Maximize2,
  File,
  Loader2,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { formatBytes } from '../utils/format';

export interface UploadTask {
  id: string;
  name: string;
  size: number;
  loaded: number;
  percentage: number;
  status: 'pending' | 'uploading' | 'completed' | 'error';
  error?: string;
}

interface UploadProgressModalProps {
  tasks: UploadTask[];
  onDismiss: () => void;
  onClearCompleted: () => void;
}

export const UploadProgressModal: React.FC<UploadProgressModalProps> = ({
  tasks,
  onDismiss,
  onClearCompleted,
}) => {
  const [isMinimized, setIsMinimized] = useState(false);

  if (tasks.length === 0) return null;

  const completedCount = tasks.filter((t) => t.status === 'completed').length;
  const isAllCompleted = completedCount === tasks.length;
  const isUploading = tasks.some((t) => t.status === 'uploading' || t.status === 'pending');

  const totalBytes = tasks.reduce((acc, t) => acc + t.size, 0);
  const totalLoaded = tasks.reduce((acc, t) => acc + (t.status === 'completed' ? t.size : t.loaded), 0);
  const overallPercentage = totalBytes > 0 ? Math.min(100, Math.round((totalLoaded / totalBytes) * 100)) : 0;

  return (
    <div className="fixed bottom-6 right-6 z-50 w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl overflow-hidden transition-all duration-300">
      {/* Header bar */}
      <div className="px-4 py-3 bg-slate-900 text-white flex items-center justify-between gap-3 border-b border-slate-800">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-8 h-8 rounded-lg bg-blue-600/30 border border-blue-500/40 flex items-center justify-center text-blue-400 shrink-0">
            {isUploading ? (
              <Loader2 className="w-4 h-4 animate-spin text-blue-400" />
            ) : (
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            )}
          </div>
          <div className="min-w-0">
            <h4 className="text-xs font-semibold truncate">
              {isUploading
                ? `Mengunggah ${tasks.length} berkas (${overallPercentage}%)`
                : `${completedCount} berkas selesai diunggah`}
            </h4>
            <p className="text-[10px] text-slate-400 font-mono tabular-nums">
              {formatBytes(totalLoaded)} dari {formatBytes(totalBytes)}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1 shrink-0">
          <button
            onClick={() => setIsMinimized(!isMinimized)}
            title={isMinimized ? 'Perbesar' : 'Minimalkan'}
            className="p-1 rounded-md hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            {isMinimized ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
          {isAllCompleted && (
            <button
              onClick={onDismiss}
              title="Tutup"
              className="p-1 rounded-md hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Main overall progress bar */}
      <div className="w-full bg-slate-200 dark:bg-slate-800 h-1.5 overflow-hidden">
        <div
          className={`h-full transition-all duration-200 ${
            isAllCompleted ? 'bg-emerald-500' : 'bg-blue-600 animate-pulse'
          }`}
          style={{ width: `${overallPercentage}%` }}
        />
      </div>

      {/* Expanded list of files with individual progress */}
      {!isMinimized && (
        <div className="max-h-72 overflow-y-auto p-3 space-y-2.5 bg-slate-50 dark:bg-slate-950 divide-y divide-slate-100 dark:divide-slate-800/40">
          {tasks.map((task) => (
            <div key={task.id} className="pt-2.5 first:pt-0">
              <div className="flex items-start justify-between gap-2 mb-1.5">
                <div className="min-w-0 flex-1">
                  <div className="text-xs font-medium text-slate-800 dark:text-slate-200 truncate">
                    {task.name}
                  </div>
                  <div className="flex items-center gap-2 text-[10px] text-slate-500 dark:text-slate-400 mt-0.5 font-mono tabular-nums">
                    <span>
                      {formatBytes(task.loaded)} / {formatBytes(task.size)}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span
                      className={
                        task.status === 'completed'
                          ? 'text-emerald-500'
                          : task.status === 'error'
                          ? 'text-rose-500'
                          : 'text-blue-500'
                      }
                    >
                      {task.status === 'completed'
                        ? 'Selesai 100%'
                        : task.status === 'error'
                        ? 'Gagal'
                        : `${task.percentage}%`}
                    </span>
                  </div>
                </div>

                <div className="shrink-0 text-right">
                  {task.status === 'uploading' && (
                    <Loader2 className="w-4 h-4 text-blue-500 animate-spin" />
                  )}
                  {task.status === 'completed' && (
                    <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                  )}
                  {task.status === 'error' && (
                    <AlertCircle className="w-4 h-4 text-rose-500" />
                  )}
                </div>
              </div>

              {/* Progress bar per file */}
              <div className="w-full bg-slate-200 dark:bg-slate-800 rounded-full h-1.5 overflow-hidden">
                <div
                  className={`h-full transition-all duration-150 rounded-full ${
                    task.status === 'completed'
                      ? 'bg-emerald-500'
                      : task.status === 'error'
                      ? 'bg-rose-500'
                      : 'bg-blue-600'
                  }`}
                  style={{ width: `${task.percentage}%` }}
                />
              </div>

              {task.error && (
                <p className="text-[10px] text-rose-500 mt-1">{task.error}</p>
              )}
            </div>
          ))}

          {/* Bottom actions */}
          {isAllCompleted && (
            <div className="pt-3 flex justify-end">
              <button
                onClick={onClearCompleted}
                className="text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 transition-colors"
              >
                Bersihkan Riwayat
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
