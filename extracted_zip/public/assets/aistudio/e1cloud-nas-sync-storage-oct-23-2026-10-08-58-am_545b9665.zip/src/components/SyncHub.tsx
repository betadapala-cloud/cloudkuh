import React, { useState } from 'react';
import {
  FolderSync,
  Smartphone,
  Laptop,
  Monitor,
  CheckCircle2,
  Clock,
  Trash2,
  Activity,
  ArrowRight,
  ShieldCheck,
  RefreshCw,
} from 'lucide-react';
import { Device, SyncLog, SyncState } from '../types';
import { formatDate } from '../utils/format';

interface SyncHubProps {
  syncState: SyncState | null;
  onToggleAutoSync: (enabled: boolean, intervalMs?: number) => void;
  onTriggerSync: () => void;
  onRemoveDevice: (id: string) => void;
  isSyncing: boolean;
}

export const SyncHub: React.FC<SyncHubProps> = ({
  syncState,
  onToggleAutoSync,
  onTriggerSync,
  onRemoveDevice,
  isSyncing,
}) => {
  const [selectedInterval, setSelectedInterval] = useState<number>(syncState?.intervalMs || 10000);

  const getDeviceIcon = (type: Device['type']) => {
    switch (type) {
      case 'android':
        return <Smartphone className="w-5 h-5 text-emerald-400" />;
      case 'windows':
      case 'linux':
        return <Laptop className="w-5 h-5 text-blue-400" />;
      case 'mac':
        return <Laptop className="w-5 h-5 text-purple-400" />;
      default:
        return <Monitor className="w-5 h-5 text-cyan-400" />;
    }
  };

  const devices = syncState?.devices || [];
  const logs = syncState?.logs || [];
  const autoSync = syncState?.autoSync ?? true;

  return (
    <div className="flex-1 overflow-y-auto p-4 sm:p-8 bg-slate-50 dark:bg-slate-950">
      <div className="max-w-6xl mx-auto space-y-6 sm:space-y-8">
        {/* Top Header Card */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 sm:p-6 shadow-xs">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 sm:gap-6">
            <div className="flex items-start gap-3 sm:gap-4">
              <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-blue-600/10 border border-blue-500/20 flex items-center justify-center text-blue-600 dark:text-blue-400 shrink-0">
                <FolderSync className={`w-5 h-5 sm:w-6 sm:h-6 ${isSyncing ? 'animate-spin' : ''}`} />
              </div>
              <div>
                <div className="flex flex-wrap items-center gap-2 sm:gap-3">
                  <h2 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white">
                    Hub Sinkronisasi Real-Time
                  </h2>
                  <span className="text-[11px] font-mono text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 px-2 py-0.5 rounded-full flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    Real-time Online
                  </span>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xl">
                  Sinkronisasi berkas otomatis antar perangkat (Android, Windows, macOS, Web) dengan penyimpanan cloud NAS di server http://nas.e1cloud.biz.id:55582.
                </p>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="flex items-center gap-3 shrink-0">
              <button
                onClick={onTriggerSync}
                disabled={isSyncing}
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-xs transition-colors disabled:opacity-60"
              >
                <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
                <span>{isSyncing ? 'Menyinkronkan...' : 'Sinkronkan Sekarang'}</span>
              </button>
            </div>
          </div>

          {/* Sync Preferences bar */}
          <div className="mt-6 pt-6 border-t border-slate-100 dark:border-slate-800/80 grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Auto sync switch */}
            <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/60">
              <div>
                <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 block">
                  Sinkronisasi Otomatis
                </span>
                <span className="text-[11px] text-slate-500">Kirim perubahan tanpa jeda manual</span>
              </div>
              <button
                onClick={() => onToggleAutoSync(!autoSync, selectedInterval)}
                className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                  autoSync ? 'bg-blue-600' : 'bg-slate-300 dark:bg-slate-700'
                }`}
              >
                <span
                  className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out ${
                    autoSync ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Sync interval */}
            <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/60">
              <div>
                <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 block">
                  Interval Pemindaian
                </span>
                <span className="text-[11px] text-slate-500">Deteksi perubahan berkas server</span>
              </div>
              <select
                value={selectedInterval}
                onChange={(e) => {
                  const val = Number(e.target.value);
                  setSelectedInterval(val);
                  onToggleAutoSync(autoSync, val);
                }}
                className="bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-xs text-slate-800 dark:text-slate-200 rounded-lg px-2.5 py-1.5 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value={5000}>5 Detik (Ultra Cepat)</option>
                <option value={10000}>10 Detik (Standar)</option>
                <option value={30000}>30 Detik (Hemat Daya)</option>
                <option value={60000}>60 Detik (Periodik)</option>
              </select>
            </div>

            {/* Sync State Badge */}
            <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/60">
              <div>
                <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 block">
                  Kesehatan Sinkronisasi
                </span>
                <span className="text-[11px] text-slate-500">Pemeriksaan integritas checksum</span>
              </div>
              <div className="flex items-center gap-1.5 text-xs font-medium text-emerald-600 dark:text-emerald-400">
                <ShieldCheck className="w-4 h-4" />
                <span>100% Selaras</span>
              </div>
            </div>
          </div>
        </div>

        {/* 2-Column Grid: Devices List and Real-Time Logs */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left Column: Connected Devices (7 cols) */}
          <div className="lg:col-span-7 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  Jaringan Perangkat Terhubung ({devices.length})
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Perangkat yang aktif melakukan sinkronisasi dengan akun admin
                </p>
              </div>
            </div>

            <div className="space-y-3">
              {devices.map((device) => {
                const isCurrent = device.id === 'dev-browser-current';
                return (
                  <div
                    key={device.id}
                    className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 transition-colors shadow-xs flex items-center justify-between gap-4"
                  >
                    <div className="flex items-center gap-3.5 min-w-0">
                      <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center shrink-0">
                        {getDeviceIcon(device.type)}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <h4 className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                            {device.name}
                          </h4>
                          {isCurrent && (
                            <span className="text-[10px] font-mono text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800 px-1.5 py-0.2 rounded">
                              PERANGKAT INI
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                          <span className="font-mono text-[11px]">{device.ip}</span>
                          <span aria-hidden="true">·</span>
                          <span className="font-mono text-[11px]">{device.clientVersion}</span>
                          <span aria-hidden="true">·</span>
                          <span className="text-emerald-500 flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                            Aktif
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      <div className="text-right hidden sm:block">
                        <div className="text-[11px] text-slate-400">Sinkron Terakhir</div>
                        <div className="text-xs font-mono tabular-nums text-slate-700 dark:text-slate-300">
                          {formatDate(device.lastSeen)}
                        </div>
                      </div>

                      {!isCurrent && (
                        <button
                          onClick={() => onRemoveDevice(device.id)}
                          title="Putus Sambungan Perangkat"
                          className="p-2 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right Column: Real-Time Sync Logs & Activity (5 cols) */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Activity className="w-4 h-4 text-blue-500" />
                  Aktivitas Sinkron Real-Time
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Log pembaruan berkas dari seluruh perangkat
                </p>
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs space-y-3 max-h-[480px] overflow-y-auto">
              {logs.length === 0 ? (
                <div className="py-8 text-center text-xs text-slate-400">
                  Belum ada log sinkronisasi tercatat
                </div>
              ) : (
                logs.map((log) => (
                  <div
                    key={log.id}
                    className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 text-xs space-y-1.5"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-slate-800 dark:text-slate-200 truncate max-w-[200px]">
                        {log.deviceName}
                      </span>
                      <span className="font-mono text-[10px] tabular-nums text-slate-400">
                        {formatDate(log.timestamp)}
                      </span>
                    </div>

                    <p className="text-slate-600 dark:text-slate-300 font-mono text-[11px] truncate">
                      {log.targetPath}
                    </p>

                    <div className="flex items-center justify-between pt-1 text-[11px] text-slate-500">
                      <span className="text-slate-600 dark:text-slate-400">{log.details || log.action}</span>
                      <span className="text-emerald-500 font-medium flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Sukses
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
