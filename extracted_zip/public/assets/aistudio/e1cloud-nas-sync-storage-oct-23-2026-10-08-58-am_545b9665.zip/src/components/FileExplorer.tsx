import React, { useState } from 'react';
import {
  UploadCloud,
  FolderOpen,
  ArrowUp,
  Folder,
  File,
  HardDrive,
  AlertCircle,
  Shuffle,
  ClipboardPaste,
  X,
  Copy,
  FolderInput,
} from 'lucide-react';
import { NasFolderData, NasItem, ClipboardItem } from '../types';
import { FileCard } from './FileCard';
import { FileRow } from './FileRow';
import { formatBytes, getFileCategory } from '../utils/format';

interface FileExplorerProps {
  currentPath: string;
  folderData: NasFolderData | null;
  isLoading: boolean;
  searchQuery: string;
  viewMode: 'grid' | 'list';
  sortBy: 'name' | 'size' | 'modified';
  sortAsc: boolean;
  clipboard: ClipboardItem | null;
  onNavigate: (path: string) => void;
  onPreview: (item: NasItem) => void;
  onDownload: (item: NasItem) => void;
  onRename: (item: NasItem) => void;
  onDelete: (item: NasItem) => void;
  onUploadFiles: (files: FileList) => void;
  onNewFolder: () => void;
  onShufflePlayFolder?: () => void;
  onCopyItem: (item: NasItem) => void;
  onMoveItem: (item: NasItem) => void;
  onPaste: () => void;
  onClearClipboard: () => void;
}

export const FileExplorer: React.FC<FileExplorerProps> = ({
  currentPath,
  folderData,
  isLoading,
  searchQuery,
  viewMode,
  sortBy,
  sortAsc,
  clipboard,
  onNavigate,
  onPreview,
  onDownload,
  onRename,
  onDelete,
  onUploadFiles,
  onNewFolder,
  onShufflePlayFolder,
  onCopyItem,
  onMoveItem,
  onPaste,
  onClearClipboard,
}) => {
  const [isDragging, setIsDragging] = useState(false);

  // Handle Drag & Drop
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      onUploadFiles(e.dataTransfer.files);
    }
  };

  // Filter items
  const items = folderData?.items || [];
  const filteredItems = items.filter((item) =>
    item.name.toLowerCase().includes(searchQuery.toLowerCase().trim())
  );

  // Sort items: folders always first, then by chosen criterion
  const sortedItems = [...filteredItems].sort((a, b) => {
    if (a.isDir && !b.isDir) return -1;
    if (!a.isDir && b.isDir) return 1;

    let comp = 0;
    if (sortBy === 'name') {
      comp = a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' });
    } else if (sortBy === 'size') {
      comp = a.size - b.size;
    } else if (sortBy === 'modified') {
      comp = new Date(a.modified).getTime() - new Date(b.modified).getTime();
    }
    return sortAsc ? comp : -comp;
  });

  const totalSize = items.reduce((acc, curr) => acc + (curr.isDir ? 0 : curr.size), 0);

  // Parent directory navigation
  const canGoUp = currentPath !== '/' && currentPath !== '';
  const handleGoUp = () => {
    const segments = currentPath.split('/').filter(Boolean);
    segments.pop();
    const parent = segments.length === 0 ? '/' : '/' + segments.join('/');
    onNavigate(parent);
  };

  return (
    <div
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      className="relative flex-1 overflow-y-auto p-3 sm:p-6 pb-24 md:pb-6 bg-slate-50 dark:bg-slate-950 flex flex-col"
    >
      {/* Drag & Drop Overlay */}
      {isDragging && (
        <div className="absolute inset-4 z-40 bg-blue-600/90 rounded-2xl flex flex-col items-center justify-center text-white backdrop-blur-xs border-2 border-dashed border-white pointer-events-none">
          <UploadCloud className="w-16 h-16 animate-bounce mb-3" />
          <h3 className="text-xl font-semibold">Lepaskan Berkas untuk Mengunggah</h3>
          <p className="text-sm text-blue-100 mt-1">
            Berkas akan langsung diunggah ke NAS di <span className="font-mono">{currentPath}</span>
          </p>
        </div>
      )}

      {/* Directory summary bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 sm:gap-3 pb-3 sm:pb-4 border-b border-slate-200 dark:border-slate-800 mb-4 sm:mb-6">
        <div className="flex items-center gap-3">
          {canGoUp && (
            <button
              onClick={handleGoUp}
              title="Kembali ke folder sebelumnya"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors shadow-xs"
            >
              <ArrowUp className="w-3.5 h-3.5 text-blue-500" />
              <span>Naik Satu Tingkat</span>
            </button>
          )}

          <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-2">
            <span>
              Total: <strong className="text-slate-800 dark:text-slate-200 font-mono tabular-nums">{items.length}</strong> item
            </span>
            <span aria-hidden="true">·</span>
            <span className="font-mono tabular-nums">{formatBytes(totalSize)}</span>
            {searchQuery && (
              <>
                <span aria-hidden="true">·</span>
                <span className="text-blue-600 dark:text-blue-400">
                  Ditemukan {filteredItems.length} hasil untuk "{searchQuery}"
                </span>
              </>
            )}
          </div>
        </div>

        {/* Right side: Shuffle play folder & drop hint */}
        <div className="flex items-center gap-3">
          {items.some(
            (it) =>
              !it.isDir &&
              (getFileCategory(it.extension, false) === 'video' ||
                getFileCategory(it.extension, false) === 'audio')
          ) && (
            <button
              onClick={onShufflePlayFolder}
              title="Acak dan putar seluruh video atau musik di dalam folder ini"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-xs transition-colors shrink-0"
            >
              <Shuffle className="w-3.5 h-3.5" />
              <span>Putar Acak Media</span>
            </button>
          )}

          {/* Quick upload drop hint */}
          <div className="hidden sm:flex items-center gap-2 text-xs text-slate-400">
            <UploadCloud className="w-4 h-4 text-blue-500" />
            <span>Tarik &amp; lepas berkas (Mendukung berkas besar &gt; 1 GB hingga 20 GB)</span>
          </div>
        </div>
      </div>

      {/* Clipboard Action Banner */}
      {clipboard && (
        <div className="mb-6 p-3.5 rounded-xl bg-blue-500/10 border border-blue-500/30 flex flex-wrap items-center justify-between gap-3 animate-in fade-in slide-in-from-top-2">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-9 h-9 rounded-lg bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-xs">
              {clipboard.action === 'copy' ? <Copy className="w-4 h-4" /> : <FolderInput className="w-4 h-4" />}
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-semibold uppercase ${
                  clipboard.action === 'copy'
                    ? 'bg-blue-600/20 text-blue-400 border border-blue-500/30'
                    : 'bg-purple-600/20 text-purple-400 border border-purple-500/30'
                }`}>
                  {clipboard.action === 'copy' ? 'Salin (Copy)' : 'Pindahkan (Move)'}
                </span>
                <span className="text-xs font-semibold text-slate-900 dark:text-slate-100 truncate max-w-xs md:max-w-md">
                  {clipboard.item.name}
                </span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 truncate">
                Siap ditempel ke folder: <span className="font-mono text-blue-600 dark:text-blue-400 font-medium">{currentPath}</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={onPaste}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-xs transition-colors"
            >
              <ClipboardPaste className="w-4 h-4" />
              <span>Tempel di Sini</span>
            </button>
            <button
              onClick={onClearClipboard}
              className="p-1.5 rounded-lg border border-slate-300 dark:border-slate-700 hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 transition-colors"
              title="Batalkan"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Loading State */}
      {isLoading && (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <div
              key={i}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 animate-pulse"
            >
              <div className="w-8 h-8 rounded-lg bg-slate-200 dark:bg-slate-800 mb-3" />
              <div className="h-4 bg-slate-200 dark:bg-slate-800 rounded w-3/4 mb-2" />
              <div className="h-3 bg-slate-100 dark:bg-slate-800/60 rounded w-1/2" />
            </div>
          ))}
        </div>
      )}

      {/* Populated State */}
      {!isLoading && sortedItems.length > 0 && (
        <>
          {viewMode === 'grid' ? (
            <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-2.5 sm:gap-4">
              {sortedItems.map((item) => (
                <FileCard
                  key={item.path}
                  item={item}
                  onOpen={(it) => {
                    if (it.isDir) onNavigate(it.path);
                    else onPreview(it);
                  }}
                  onPreview={onPreview}
                  onDownload={onDownload}
                  onRename={onRename}
                  onDelete={onDelete}
                  onCopy={onCopyItem}
                  onMove={onMoveItem}
                />
              ))}
            </div>
          ) : (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-xs">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                      <th className="py-3 px-3 sm:px-4">Nama</th>
                      <th className="py-3 px-2 sm:px-4">Ukuran</th>
                      <th className="hidden md:table-cell py-3 px-4">Modifikasi</th>
                      <th className="hidden sm:table-cell py-3 px-4">Tipe</th>
                      <th className="py-3 px-3 sm:px-4 text-right">Aksi</th>
                    </tr>
                  </thead>
                  <tbody>
                    {sortedItems.map((item) => (
                      <FileRow
                        key={item.path}
                        item={item}
                        onOpen={(it) => {
                          if (it.isDir) onNavigate(it.path);
                          else onPreview(it);
                        }}
                        onPreview={onPreview}
                        onDownload={onDownload}
                        onRename={onRename}
                        onDelete={onDelete}
                        onCopy={onCopyItem}
                        onMove={onMoveItem}
                      />
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </>
      )}

      {/* Empty State */}
      {!isLoading && sortedItems.length === 0 && (
        <div className="flex-1 flex flex-col items-center justify-center py-16 text-center">
          <div className="w-16 h-16 rounded-2xl bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center justify-center text-slate-400 mb-4">
            <FolderOpen className="w-8 h-8" />
          </div>
          <h3 className="text-base font-semibold text-slate-800 dark:text-slate-200">
            {searchQuery ? 'Tidak Ada Berkas Ditemukan' : 'Folder Ini Kosong'}
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mt-1 mb-6">
            {searchQuery
              ? `Tidak ditemukan berkas yang cocok dengan "${searchQuery}". Coba kata kunci lain.`
              : 'Belum ada berkas di dalam folder ini. Anda dapat mengunggah berkas sekarang atau membuat folder baru.'}
          </p>

          <div className="flex items-center gap-3">
            <button
              onClick={onNewFolder}
              className="px-4 py-2 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors"
            >
              Buat Folder
            </button>
            <label className="cursor-pointer px-4 py-2 text-xs font-medium rounded-lg bg-blue-600 hover:bg-blue-700 text-white transition-colors">
              <span>Unggah Berkas</span>
              <input
                type="file"
                multiple
                className="hidden"
                onChange={(e) => e.target.files && onUploadFiles(e.target.files)}
              />
            </label>
          </div>
        </div>
      )}
    </div>
  );
};
