import React from 'react';
import {
  HardDrive,
  FolderSync,
  Globe,
  Folder,
  Smartphone,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  Laptop,
  X,
} from 'lucide-react';
import { NasStatus, SyncState } from '../types';

interface SidebarProps {
  activeTab: 'files' | 'sync' | 'portal';
  setActiveTab: (tab: 'files' | 'sync' | 'portal') => void;
  nasStatus: NasStatus | null;
  syncState: SyncState | null;
  currentPath: string;
  onNavigate: (path: string) => void;
  isSyncing: boolean;
  onTriggerSync: () => void;
  isMobileOpen?: boolean;
  onMobileClose?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  nasStatus,
  syncState,
  onNavigate,
  isSyncing,
  onTriggerSync,
  isMobileOpen = false,
  onMobileClose,
}) => {
  const handleNavClick = (tab: 'files' | 'sync' | 'portal', path?: string) => {
    setActiveTab(tab);
    if (path) onNavigate(path);
    if (onMobileClose) onMobileClose();
  };

  const renderContent = () => (
    <div className="flex flex-col h-full text-slate-300">
      {/* Brand & Connection Header */}
      <div className="p-4 border-b border-slate-800 flex items-center justify-between gap-2">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400 shrink-0">
            <HardDrive className="w-5 h-5" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <h1 className="font-semibold text-white text-base tracking-tight truncate">
                DJ92Cloud
              </h1>
              <span className="inline-flex items-center text-[10px] font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-1.5 py-0.2 rounded">
                LIVE
              </span>
            </div>
            <p className="text-xs text-slate-400 truncate">Penyimpanan &amp; Sinkronisasi @joko92m</p>
          </div>
        </div>

        {/* Mobile close button */}
        {onMobileClose && (
          <button
            onClick={onMobileClose}
            className="md:hidden p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            title="Tutup Menu"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* Server & User quick tag */}
      <div className="p-4 pb-2">
        <div className="p-2.5 rounded-lg bg-slate-800/60 border border-slate-700/60 text-xs">
          <div className="flex items-center justify-between">
            <span className="text-slate-400">Server NAS</span>
            <span className="text-blue-400 font-mono text-[11px] truncate max-w-[130px]">
              nas.e1cloud.biz.id
            </span>
          </div>
          <div className="flex items-center justify-between mt-1 pt-1 border-t border-slate-700/40">
            <span className="text-slate-400">Pengguna</span>
            <span className="text-slate-200 font-medium font-mono text-[11px]">admin</span>
          </div>
          <div className="flex items-center justify-between mt-1">
            <span className="text-slate-400">Status Latensi</span>
            <div className="flex items-center gap-1.5 font-mono text-[11px] tabular-nums">
              {nasStatus?.authenticated ? (
                <>
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                  <span className="text-emerald-400">{nasStatus.latencyMs}ms</span>
                </>
              ) : (
                <>
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                  <span className="text-amber-400">Menghubungkan...</span>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Main Nav Links */}
      <div className="flex-1 overflow-y-auto px-3 py-4 space-y-6">
        <div>
          <div className="text-[11px] font-medium tracking-wider text-slate-400 uppercase px-3 mb-2">
            Penyimpanan Berkas
          </div>
          <nav className="space-y-1">
            <button
              onClick={() => handleNavClick('files', '/')}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeTab === 'files'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
              }`}
            >
              <Folder className="w-4 h-4 shrink-0" />
              <span className="truncate">Semua Berkas (Root)</span>
            </button>
          </nav>
        </div>

        {/* Sync & Portal Tools */}
        <div>
          <div className="text-[11px] font-medium tracking-wider text-slate-400 uppercase px-3 mb-2">
            Konektivitas &amp; Akses
          </div>
          <nav className="space-y-1">
            <button
              onClick={() => handleNavClick('sync')}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeTab === 'sync'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-3 truncate">
                <FolderSync className={`w-4 h-4 shrink-0 ${isSyncing ? 'animate-spin text-blue-300' : ''}`} />
                <span className="truncate">Sinkronisasi Real-Time</span>
              </div>
              <span className="text-[11px] font-mono tabular-nums text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded shrink-0">
                {syncState?.devices?.length || 4} Dev
              </span>
            </button>

            <button
              onClick={() => handleNavClick('portal')}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeTab === 'portal'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
              }`}
            >
              <Globe className="w-4 h-4 shrink-0 text-cyan-400" />
              <span className="truncate">Portal Langsung NAS</span>
            </button>
          </nav>
        </div>

        {/* Multi-Device Mesh status */}
        <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-800">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-300">Sinkron Antar Perangkat</span>
            <span className="text-[10px] text-emerald-400 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              Otomatis
            </span>
          </div>

          <div className="space-y-2 text-xs">
            <div className="flex items-center justify-between text-slate-400">
              <div className="flex items-center gap-2">
                <Laptop className="w-3.5 h-3.5 text-blue-400" />
                <span className="truncate max-w-[130px]">Browser ini</span>
              </div>
              <span className="text-[10px] text-slate-400 font-mono">Aktif</span>
            </div>
            <div className="flex items-center justify-between text-slate-400">
              <div className="flex items-center gap-2">
                <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
                <span className="truncate max-w-[130px]">Galaxy S24 (APK)</span>
              </div>
              <span className="text-[10px] text-slate-400 font-mono">Real-time</span>
            </div>
          </div>

          <button
            onClick={onTriggerSync}
            disabled={isSyncing}
            className="w-full mt-3 py-1.5 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
          >
            <FolderSync className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>{isSyncing ? 'Menyinkronkan...' : 'Sinkron Sekarang'}</span>
          </button>
        </div>
      </div>

      {/* Footer Credentials Reminder */}
      <div className="p-3 border-t border-slate-800 text-xs text-slate-400 bg-slate-900/60">
        <a
          href="http://nas.e1cloud.biz.id:55582/files/"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center justify-between p-2 rounded-lg bg-slate-800/80 hover:bg-slate-800 text-slate-200 transition-colors group"
        >
          <div className="truncate">
            <div className="text-[11px] text-slate-400">Akses Web Asli</div>
            <div className="text-xs font-medium text-white truncate">nas.e1cloud.biz.id:55582</div>
          </div>
          <ExternalLink className="w-4 h-4 text-slate-400 group-hover:text-blue-400 transition-colors shrink-0 ml-2" />
        </a>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Persistent Sidebar */}
      <aside className="hidden md:flex w-72 bg-slate-900 border-r border-slate-800 flex-col shrink-0 text-slate-300 h-full">
        {renderContent()}
      </aside>

      {/* Mobile Drawer (Visible on smartphones when toggled) */}
      {isMobileOpen && (
        <div className="fixed inset-0 z-50 md:hidden flex animate-in fade-in duration-150">
          <div
            className="fixed inset-0 bg-black/70 backdrop-blur-xs"
            onClick={onMobileClose}
          />
          <aside className="relative w-72 max-w-[85vw] bg-slate-900 border-r border-slate-800 flex flex-col h-full shadow-2xl z-10 animate-in slide-in-from-left duration-200">
            {renderContent()}
          </aside>
        </div>
      )}
    </>
  );
};
