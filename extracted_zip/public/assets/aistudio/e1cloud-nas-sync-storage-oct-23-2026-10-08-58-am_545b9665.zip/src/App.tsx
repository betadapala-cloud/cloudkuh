import React, { useState, useEffect, useRef } from 'react';
import { Sidebar } from './components/Sidebar';
import { Navbar } from './components/Navbar';
import { FileExplorer } from './components/FileExplorer';
import { SyncHub } from './components/SyncHub';
import { NasPortalDirect } from './components/NasPortalDirect';
import { FilePreviewModal } from './components/FilePreviewModal';
import { NewFolderModal } from './components/NewFolderModal';
import { RenameModal } from './components/RenameModal';
import { DeleteModal } from './components/DeleteModal';
import { UploadProgressModal, UploadTask } from './components/UploadProgressModal';
import { MediaPlayer } from './components/MediaPlayer';
import { MiniPlayerBar } from './components/MiniPlayerBar';
import { api } from './services/api';
import { NasFolderData, NasItem, NasStatus, SyncState, WebCredentials, ClipboardItem } from './types';
import { getFileCategory } from './utils/format';
import { CheckCircle2, AlertCircle, X, FolderSync, Shuffle, Folder, Globe } from 'lucide-react';

interface Toast {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<'files' | 'sync' | 'portal'>('files');
  const [currentPath, setCurrentPath] = useState<string>('/');
  const [folderData, setFolderData] = useState<NasFolderData | null>(null);
  const [nasStatus, setNasStatus] = useState<NasStatus | null>(null);
  const [syncState, setSyncState] = useState<SyncState | null>(null);
  const [credentials, setCredentials] = useState<WebCredentials | null>(null);

  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [sortBy, setSortBy] = useState<'name' | 'size' | 'modified'>('name');
  const [sortAsc, setSortAsc] = useState<boolean>(true);

  // Mobile sidebar drawer state
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState<boolean>(false);

  // Active clipboard for copy/move operations
  const [clipboard, setClipboard] = useState<ClipboardItem | null>(null);

  // Upload progress tracking tasks
  const [uploadTasks, setUploadTasks] = useState<UploadTask[]>([]);

  // Media Player & Shuffle playback states
  const [activeMediaTrack, setActiveMediaTrack] = useState<NasItem | null>(null);
  const [isMediaModalOpen, setIsMediaModalOpen] = useState<boolean>(false);
  const [isShuffle, setIsShuffle] = useState<boolean>(true); // Shuffle is ON by default as requested
  const [repeatMode, setRepeatMode] = useState<'off' | 'all' | 'one'>('all');
  const [isMiniPlaying, setIsMiniPlaying] = useState<boolean>(true);

  // Modals for other files
  const [previewItem, setPreviewItem] = useState<NasItem | null>(null);
  const [renamingItem, setRenamingItem] = useState<NasItem | null>(null);
  const [deletingItem, setDeletingItem] = useState<NasItem | null>(null);
  const [isNewFolderOpen, setIsNewFolderOpen] = useState<boolean>(false);

  // Toasts
  const [toasts, setToasts] = useState<Toast[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    setToasts((prev) => [...prev, { id, type, message }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  };

  // Load files for current path
  const loadFiles = async (targetPath: string) => {
    try {
      setIsLoading(true);
      const res = await api.getFiles(targetPath);
      setFolderData(res.data);
      setCurrentPath(res.currentPath);
    } catch (err: any) {
      showToast(err.message || 'Gagal memuat berkas dari NAS', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  // Load initial NAS status and sync state
  const loadInitialData = async () => {
    try {
      const [statusRes, syncRes, credRes] = await Promise.all([
        api.getStatus(),
        api.getSyncState(),
        api.getWebCredentials(),
      ]);
      setNasStatus(statusRes);
      setSyncState(syncRes);
      setCredentials(credRes);
    } catch (err: any) {
      console.error('Error fetching status:', err);
    }
  };

  useEffect(() => {
    loadInitialData();
    loadFiles(currentPath);
  }, []);

  // SSE real-time sync subscription
  useEffect(() => {
    const sse = new EventSource('/api/sync/events');

    sse.addEventListener('init', (e: any) => {
      try {
        const data = JSON.parse(e.data);
        if (data.devices) {
          setSyncState((prev) => (prev ? { ...prev, devices: data.devices } : null));
        }
      } catch (err) {
        console.error(err);
      }
    });

    sse.addEventListener('sync_event', (e: any) => {
      try {
        const data = JSON.parse(e.data);
        loadFiles(currentPath);
        api.getSyncState().then(setSyncState);

        if (data.log?.details) {
          showToast(data.log.details, 'info');
        }
      } catch (err) {
        console.error(err);
      }
    });

    sse.addEventListener('heartbeat', (e: any) => {
      try {
        const data = JSON.parse(e.data);
        setNasStatus((prev) => (prev ? { ...prev, lastSyncCheck: data.timestamp } : null));
      } catch (err) {
        console.error(err);
      }
    });

    sse.addEventListener('device_registered', (e: any) => {
      try {
        const data = JSON.parse(e.data);
        if (data.devices) {
          setSyncState((prev) => (prev ? { ...prev, devices: data.devices } : null));
        }
        if (data.device) {
          showToast(`Perangkat baru "${data.device.name}" terhubung ke sinkronisasi`, 'success');
        }
      } catch (err) {
        console.error(err);
      }
    });

    sse.addEventListener('device_removed', (e: any) => {
      try {
        const data = JSON.parse(e.data);
        if (data.devices) {
          setSyncState((prev) => (prev ? { ...prev, devices: data.devices } : null));
        }
      } catch (err) {
        console.error(err);
      }
    });

    return () => {
      sse.close();
    };
  }, [currentPath]);

  // Navigate folder
  const handleNavigate = (path: string) => {
    loadFiles(path);
  };

  // Media playlist for current folder
  const currentFolderMedia = (folderData?.items || []).filter(
    (it) =>
      !it.isDir &&
      (getFileCategory(it.extension, false) === 'video' ||
        getFileCategory(it.extension, false) === 'audio')
  );

  // Open item handler: If audio/video, open MediaPlayer; otherwise preview
  const handlePreviewOrPlay = (item: NasItem) => {
    const cat = getFileCategory(item.extension, false);
    if (cat === 'video' || cat === 'audio') {
      setActiveMediaTrack(item);
      setIsMediaModalOpen(true);
      setIsMiniPlaying(true);
    } else {
      setPreviewItem(item);
    }
  };

  // Shuffle play entire folder
  const handleShufflePlayFolder = () => {
    if (currentFolderMedia.length === 0) {
      showToast('Tidak ada video atau musik di dalam folder ini', 'info');
      return;
    }

    const randIdx = Math.floor(Math.random() * currentFolderMedia.length);
    const chosenTrack = currentFolderMedia[randIdx];
    setIsShuffle(true);
    setActiveMediaTrack(chosenTrack);
    setIsMediaModalOpen(true);
    setIsMiniPlaying(true);
    showToast(`Memutar acak: "${chosenTrack.name}"`, 'success');
  };

  // MiniPlayer next track
  const handleNextMedia = () => {
    if (currentFolderMedia.length <= 1 || !activeMediaTrack) return;
    const curIdx = currentFolderMedia.findIndex((t) => t.path === activeMediaTrack.path);

    if (isShuffle) {
      const candidates = currentFolderMedia
        .map((_, i) => i)
        .filter((i) => i !== curIdx);
      const randIdx = candidates[Math.floor(Math.random() * candidates.length)];
      setActiveMediaTrack(currentFolderMedia[randIdx]);
    } else {
      if (curIdx < currentFolderMedia.length - 1) {
        setActiveMediaTrack(currentFolderMedia[curIdx + 1]);
      } else {
        setActiveMediaTrack(currentFolderMedia[0]);
      }
    }
  };

  // MiniPlayer previous track
  const handlePrevMedia = () => {
    if (currentFolderMedia.length <= 1 || !activeMediaTrack) return;
    const curIdx = currentFolderMedia.findIndex((t) => t.path === activeMediaTrack.path);
    if (curIdx > 0) {
      setActiveMediaTrack(currentFolderMedia[curIdx - 1]);
    } else {
      setActiveMediaTrack(currentFolderMedia[currentFolderMedia.length - 1]);
    }
  };

  // Upload files handler with progress tracking
  const handleUploadFiles = async (files: FileList) => {
    if (!files || files.length === 0) return;

    // Build initial task queue
    const newTasks: UploadTask[] = Array.from(files).map((file, idx) => ({
      id: `task-${Date.now()}-${idx}`,
      name: file.name,
      size: file.size,
      loaded: 0,
      percentage: 0,
      status: 'pending',
    }));

    setUploadTasks((prev) => [...prev, ...newTasks]);

    let successCount = 0;

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const taskId = newTasks[i].id;

      setUploadTasks((prev) =>
        prev.map((t) => (t.id === taskId ? { ...t, status: 'uploading' } : t))
      );

      try {
        await api.uploadFile(currentPath, file, (progress) => {
          setUploadTasks((prev) =>
            prev.map((t) =>
              t.id === taskId
                ? {
                    ...t,
                    loaded: progress.loaded,
                    percentage: progress.percentage,
                  }
                : t
            )
          );
        });

        setUploadTasks((prev) =>
          prev.map((t) =>
            t.id === taskId
              ? {
                  ...t,
                  loaded: file.size,
                  percentage: 100,
                  status: 'completed',
                }
              : t
          )
        );
        successCount++;
      } catch (err: any) {
        setUploadTasks((prev) =>
          prev.map((t) =>
            t.id === taskId
              ? {
                  ...t,
                  status: 'error',
                  error: err.message || 'Gagal mengunggah',
                }
              : t
          )
        );
        showToast(`Gagal mengunggah ${file.name}: ${err.message}`, 'error');
      }
    }

    if (successCount > 0) {
      showToast(`${successCount} berkas berhasil diunggah ke NAS`, 'success');
      loadFiles(currentPath);
    }
  };

  // Create folder handler
  const handleCreateFolder = async (folderName: string) => {
    const cleanDir = currentPath.endsWith('/') ? currentPath : `${currentPath}/`;
    const newPath = `${cleanDir}${folderName}/`;
    await api.createFolder(newPath);
    showToast(`Folder "${folderName}" berhasil dibuat`, 'success');
    loadFiles(currentPath);
  };

  // Rename item handler
  const handleRename = async (sourcePath: string, newName: string) => {
    const dir = sourcePath.substring(0, sourcePath.lastIndexOf('/'));
    const isDir = sourcePath.endsWith('/');
    const dest = `${dir}/${newName}${isDir ? '/' : ''}`;
    await api.renameItem(sourcePath, dest);
    showToast(`Nama berhasil diubah menjadi "${newName}"`, 'success');
    loadFiles(currentPath);
  };

  // Delete item handler
  const handleDelete = async (item: NasItem) => {
    await api.deleteItem(item.path);
    showToast(`"${item.name}" berhasil dihapus`, 'success');
    loadFiles(currentPath);
  };

  // Download item handler
  const handleDownload = (item: NasItem) => {
    const url = api.getRawFileUrl(item.path, true);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', item.name);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast(`Mengunduh "${item.name}"...`, 'info');
  };

  // Copy item to clipboard
  const handleCopyItem = (item: NasItem) => {
    setClipboard({ action: 'copy', item });
    showToast(`"${item.name}" disalin ke papan klip. Buka folder tujuan lalu klik Tempel.`, 'info');
  };

  // Move item to clipboard
  const handleMoveItem = (item: NasItem) => {
    setClipboard({ action: 'move', item });
    showToast(`"${item.name}" dipilih untuk dipindahkan. Buka folder tujuan lalu klik Tempel.`, 'info');
  };

  // Clear clipboard
  const handleClearClipboard = () => {
    setClipboard(null);
    showToast('Papan klip dibatalkan', 'info');
  };

  // Paste item to current directory
  const handlePaste = async () => {
    if (!clipboard) return;
    const { action, item } = clipboard;
    const cleanDir = currentPath.endsWith('/') ? currentPath : `${currentPath}/`;
    const destinationPath = `${cleanDir}${item.name}${item.isDir ? '/' : ''}`;

    if (item.path === destinationPath) {
      showToast('Berkas atau folder sudah berada di lokasi ini', 'error');
      return;
    }

    try {
      if (action === 'copy') {
        await api.copyItem(item.path, destinationPath);
        showToast(`"${item.name}" berhasil disalin ke folder ini`, 'success');
      } else {
        await api.moveItem(item.path, destinationPath);
        showToast(`"${item.name}" berhasil dipindahkan ke folder ini`, 'success');
        setClipboard(null); // Clear clipboard after moving
      }
      loadFiles(currentPath);
    } catch (err: any) {
      showToast(`Gagal ${action === 'copy' ? 'menyalin' : 'memindahkan'}: ${err.message}`, 'error');
    }
  };

  // Trigger manual sync
  const handleTriggerSync = async () => {
    try {
      setIsSyncing(true);
      await api.triggerSync(currentPath);
      const updatedState = await api.getSyncState();
      setSyncState(updatedState);
      showToast('Sinkronisasi instan antar perangkat berhasil diselesaikan', 'success');
      loadFiles(currentPath);
    } catch (err: any) {
      showToast(err.message || 'Gagal menyinkronkan', 'error');
    } finally {
      setTimeout(() => setIsSyncing(false), 800);
    }
  };

  // Toggle auto sync
  const handleToggleAutoSync = async (enabled: boolean, intervalMs?: number) => {
    try {
      await api.toggleAutoSync(enabled, intervalMs);
      setSyncState((prev) => (prev ? { ...prev, autoSync: enabled, intervalMs: intervalMs || prev.intervalMs } : null));
      showToast(enabled ? 'Sinkronisasi otomatis diaktifkan' : 'Sinkronisasi otomatis dijeda', 'info');
    } catch (err: any) {
      showToast('Gagal mengubah pengaturan sinkronisasi', 'error');
    }
  };

  // Remove device
  const handleRemoveDevice = async (id: string) => {
    await api.removeDevice(id);
    const updatedState = await api.getSyncState();
    setSyncState(updatedState);
    showToast('Perangkat berhasil diputus', 'info');
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-900 text-slate-100 font-sans antialiased">
      {/* Hidden file input for upload button */}
      <input
        type="file"
        ref={fileInputRef}
        multiple
        className="hidden"
        onChange={(e) => {
          if (e.target.files) {
            handleUploadFiles(e.target.files);
            e.target.value = '';
          }
        }}
      />

      {/* Sidebar (Desktop and Mobile Drawer) */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        nasStatus={nasStatus}
        syncState={syncState}
        currentPath={currentPath}
        onNavigate={handleNavigate}
        isSyncing={isSyncing}
        onTriggerSync={handleTriggerSync}
        isMobileOpen={isMobileSidebarOpen}
        onMobileClose={() => setIsMobileSidebarOpen(false)}
      />

      {/* Main Content Viewport */}
      <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden bg-slate-50 dark:bg-slate-950 relative">
        {/* Top Navigation Bar */}
        <Navbar
          currentPath={currentPath}
          onNavigate={handleNavigate}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          viewMode={viewMode}
          setViewMode={setViewMode}
          sortBy={sortBy}
          setSortBy={setSortBy}
          sortAsc={sortAsc}
          setSortAsc={setSortAsc}
          onUploadClick={() => fileInputRef.current?.click()}
          onNewFolderClick={() => setIsNewFolderOpen(true)}
          onRefresh={() => loadFiles(currentPath)}
          onTriggerSync={handleTriggerSync}
          isSyncing={isSyncing}
          isLoading={isLoading}
          clipboard={clipboard}
          onPasteClick={handlePaste}
          onToggleMobileSidebar={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)}
        />

        {/* Tab Views */}
        <main className="flex-1 flex flex-col min-w-0 overflow-hidden relative">
          {activeTab === 'files' && (
            <FileExplorer
              currentPath={currentPath}
              folderData={folderData}
              isLoading={isLoading}
              searchQuery={searchQuery}
              viewMode={viewMode}
              sortBy={sortBy}
              sortAsc={sortAsc}
              clipboard={clipboard}
              onNavigate={handleNavigate}
              onPreview={handlePreviewOrPlay}
              onDownload={handleDownload}
              onRename={setRenamingItem}
              onDelete={setDeletingItem}
              onUploadFiles={handleUploadFiles}
              onNewFolder={() => setIsNewFolderOpen(true)}
              onShufflePlayFolder={handleShufflePlayFolder}
              onCopyItem={handleCopyItem}
              onMoveItem={handleMoveItem}
              onPaste={handlePaste}
              onClearClipboard={handleClearClipboard}
            />
          )}

          {activeTab === 'sync' && (
            <SyncHub
              syncState={syncState}
              onToggleAutoSync={handleToggleAutoSync}
              onTriggerSync={handleTriggerSync}
              onRemoveDevice={handleRemoveDevice}
              isSyncing={isSyncing}
            />
          )}

          {activeTab === 'portal' && (
            <NasPortalDirect nasStatus={nasStatus} credentials={credentials} />
          )}
        </main>

        {/* Mobile Bottom Navigation Bar (Optimized for Smartphones) */}
        <nav aria-label="Mobile Navigation" className="md:hidden fixed bottom-0 inset-x-0 z-30 bg-slate-900/95 border-t border-slate-800 backdrop-blur-md px-4 py-2 flex items-center justify-around shadow-2xl safe-area-pb">
          <button
            onClick={() => {
              setActiveTab('files');
              handleNavigate('/');
            }}
            className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl transition-all ${
              activeTab === 'files'
                ? 'text-blue-400 font-semibold scale-105'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Folder className="w-5 h-5" />
            <span className="text-[10px]">Semua Berkas</span>
          </button>

          <button
            onClick={() => setActiveTab('sync')}
            className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl transition-all relative ${
              activeTab === 'sync'
                ? 'text-blue-400 font-semibold scale-105'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <div className="relative">
              <FolderSync className={`w-5 h-5 ${isSyncing ? 'animate-spin' : ''}`} />
              <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-emerald-400 ring-2 ring-slate-900" />
            </div>
            <span className="text-[10px]">Sinkron</span>
          </button>

          <button
            onClick={() => setActiveTab('portal')}
            className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl transition-all ${
              activeTab === 'portal'
                ? 'text-blue-400 font-semibold scale-105'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Globe className="w-5 h-5 text-cyan-400" />
            <span className="text-[10px]">Portal NAS</span>
          </button>
        </nav>
      </div>

      {/* Dedicated Shuffle Media Player Modal (for Video & Music) */}
      {isMediaModalOpen && activeMediaTrack && (
        <MediaPlayer
          currentTrack={activeMediaTrack}
          playlist={currentFolderMedia}
          onSelectTrack={setActiveMediaTrack}
          onClose={() => setIsMediaModalOpen(false)}
          isShuffle={isShuffle}
          onToggleShuffle={() => {
            setIsShuffle(!isShuffle);
            showToast(!isShuffle ? 'Mode acak diaktifkan' : 'Mode acak dinonaktifkan', 'info');
          }}
          repeatMode={repeatMode}
          onCycleRepeatMode={() => {
            const nextMode = repeatMode === 'off' ? 'all' : repeatMode === 'all' ? 'one' : 'off';
            setRepeatMode(nextMode);
          }}
          onDownload={handleDownload}
        />
      )}

      {/* Floating Bottom Mini Player Bar (when minimized while listening) */}
      {!isMediaModalOpen && activeMediaTrack && (
        <MiniPlayerBar
          currentTrack={activeMediaTrack}
          isPlaying={isMiniPlaying}
          onTogglePlay={() => setIsMiniPlaying(!isMiniPlaying)}
          onNext={handleNextMedia}
          onPrev={handlePrevMedia}
          isShuffle={isShuffle}
          onToggleShuffle={() => {
            setIsShuffle(!isShuffle);
            showToast(!isShuffle ? 'Mode acak diaktifkan' : 'Mode acak dinonaktifkan', 'info');
          }}
          onExpand={() => setIsMediaModalOpen(true)}
          onStop={() => setActiveMediaTrack(null)}
        />
      )}

      {/* File Preview Modal for Images, Documents, and Archives */}
      <FilePreviewModal
        item={previewItem}
        allItems={folderData?.items || []}
        onSelectItem={setPreviewItem}
        onClose={() => setPreviewItem(null)}
        onDownload={handleDownload}
      />

      {/* Upload Progress Drawer / Modal */}
      <UploadProgressModal
        tasks={uploadTasks}
        onDismiss={() => setUploadTasks([])}
        onClearCompleted={() =>
          setUploadTasks((prev) => prev.filter((t) => t.status === 'uploading' || t.status === 'pending'))
        }
      />

      <NewFolderModal
        isOpen={isNewFolderOpen}
        currentPath={currentPath}
        onClose={() => setIsNewFolderOpen(false)}
        onCreate={handleCreateFolder}
      />

      <RenameModal
        item={renamingItem}
        onClose={() => setRenamingItem(null)}
        onRename={handleRename}
      />

      <DeleteModal
        item={deletingItem}
        onClose={() => setDeletingItem(null)}
        onConfirm={handleDelete}
      />


      {/* Toast Notifications */}
      <div className="fixed bottom-6 left-6 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className={`pointer-events-auto flex items-start gap-3 p-3.5 rounded-xl border shadow-xl backdrop-blur-md transition-all animate-in slide-in-from-bottom-2 ${
              toast.type === 'success'
                ? 'bg-slate-900/95 border-emerald-500/40 text-emerald-300'
                : toast.type === 'error'
                ? 'bg-slate-900/95 border-rose-500/40 text-rose-300'
                : 'bg-slate-900/95 border-blue-500/40 text-blue-200'
            }`}
          >
            {toast.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            ) : toast.type === 'error' ? (
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            ) : (
              <FolderSync className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
            )}
            <span className="text-xs font-medium flex-1 text-slate-200">{toast.message}</span>
            <button
              onClick={() => setToasts((prev) => prev.filter((t) => t.id !== toast.id))}
              className="text-slate-400 hover:text-white"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
